
draw(context);

// var lastUpdate = 0;
// var refreshTime = 0;

// function tick(){
//     var now = performance.now();
//     var deltaTime = now - lastUpdate;
//     lastUpdate = now;
//     refreshTime += deltaTime / 1000; // in seconds

//     // display FPS info every 0.1 s
//     if (refreshTime > 0.01){
//         console.log('HELLO');

//         clear(context);
//         draw(context);
//         refreshTime = 0;
//     }
// }

// function animate(canvas){
//     // tick();
//     requestAnimationFrame(animate);
// }

// animate(canvas);
