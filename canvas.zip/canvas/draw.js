var circle = {
    positionX: 100,
    positionY: 100,
    speed: 5 // pixels per second
}

function draw(context){
    // circle.positionX += circle.speed;

    context.fillStyle = "rgb(200, 0, 0)";
    context.fillRect (200, 300, 100, 80);

    context.fillStyle = "rgba(0, 0, 200, 0.5)";
    context.beginPath();
    context.arc(circle.positionX, circle.positionY, 50, 0, Math.PI*2, true);
    context.fill();
}

function clear(context){
	context.clearRect(0 , 0 , canvas.width, canvas.height);
}
